# MotawakilGPT Android App

A native Android application converted from the MotawakilGPT web app — an AI chat assistant powered by Google Gemini and Supabase.

---

## Project Structure

```
MotawakilGPT/
├── app/
│   ├── build.gradle                          # App-level Gradle config
│   ├── proguard-rules.pro                    # Release optimisation rules
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/motawakilgpt/app/
│       │   ├── data/
│       │   │   ├── models/Models.kt          # All data classes
│       │   │   └── repository/
│       │   │       ├── AIRepository.kt       # Gemini API calls
│       │   │       ├── AuthRepository.kt     # Supabase auth
│       │   │       └── ChatRepository.kt     # Supabase DB (chats & messages)
│       │   ├── network/
│       │   │   ├── GeminiApiService.kt       # Retrofit interface → Gemini
│       │   │   ├── RetrofitClient.kt         # Singleton HTTP clients
│       │   │   └── SupabaseApiService.kt     # Retrofit interfaces → Supabase
│       │   ├── ui/
│       │   │   ├── Components.kt             # Shared Compose components
│       │   │   ├── Theme.kt                  # MaterialTheme + brand colours
│       │   │   ├── activities/
│       │   │   │   ├── SplashActivity.kt     # Animated splash + auth check
│       │   │   │   ├── LandingActivity.kt    # Marketing home screen
│       │   │   │   ├── AuthActivity.kt       # Login / sign-up / password reset
│       │   │   │   ├── MainActivity.kt       # Chat list drawer + main layout
│       │   │   │   ├── ChatWindow.kt         # Chat messages + input + markdown
│       │   │   │   └── SettingsActivity.kt   # API key + language toggle
│       │   │   └── viewmodels/
│       │   │       ├── AuthViewModel.kt
│       │   │       ├── ChatViewModel.kt
│       │   │       └── SettingsViewModel.kt
│       │   └── utils/
│       │       ├── Extensions.kt             # Network check, toast, URL helpers
│       │       ├── I18n.kt                   # English + Persian string tables
│       │       └── SessionManager.kt         # DataStore token persistence
│       └── res/
│           ├── drawable/
│           │   ├── ic_launcher_background.xml
│           │   ├── ic_launcher_foreground.xml
│           │   └── ic_splash_logo.xml
│           ├── mipmap-mdpi/      ic_launcher.png + ic_launcher_round.png
│           ├── mipmap-hdpi/      …
│           ├── mipmap-xhdpi/     …
│           ├── mipmap-xxhdpi/    …
│           ├── mipmap-xxxhdpi/   …
│           ├── mipmap-anydpi-v26/
│           │   ├── ic_launcher.xml
│           │   └── ic_launcher_round.xml
│           ├── values/
│           │   ├── colors.xml
│           │   ├── strings.xml
│           │   └── themes.xml
│           └── xml/
│               ├── backup_rules.xml
│               ├── data_extraction_rules.xml
│               ├── file_paths.xml
│               └── network_security_config.xml
├── gradle/
│   ├── libs.versions.toml                    # Version catalog
│   └── wrapper/
│       ├── gradle-wrapper.jar                # Downloaded by Android Studio
│       └── gradle-wrapper.properties
├── build.gradle                              # Project-level Gradle
├── settings.gradle
├── gradle.properties
├── gradlew                                   # Linux/macOS build script
├── gradlew.bat                               # Windows build script
└── .gitignore
```

---

## Prerequisites

| Tool | Minimum version |
|------|----------------|
| Android Studio | Ladybug (2024.2) or newer |
| JDK | 17 |
| Android SDK | API 35 (targetSdk) |
| Minimum device | API 26 (Android 8.0) |

---

## Step 1 — Open in Android Studio

1. Launch **Android Studio**.  
2. Choose **File → Open** and select the `MotawakilGPT/` folder.  
3. Wait for **Gradle sync** to finish (it downloads dependencies automatically).  
   > If you see *"Gradle wrapper jar is missing"*, click **OK** — Android Studio downloads it.

---

## Step 2 — Get a free Gemini API key

1. Visit [https://aistudio.google.com/apikey](https://aistudio.google.com/apikey).  
2. Sign in with any Google account and click **Create API Key**.  
3. Copy the key — you'll paste it inside the app (no rebuild needed).

---

## Step 3 — Configure your Supabase project (already pre-filled)

The project already points to the original Supabase instance:

```
SUPABASE_URL  = https://rofvkjefbbrsgxwgpphw.supabase.co
SUPABASE_ANON_KEY = (see app/build.gradle)
```

To use **your own** Supabase project, open `app/build.gradle` and replace both `buildConfigField` values, then run the SQL migrations in `supabase/migrations/` from the website source against your new project.

---

## Step 4 — Build & Run

### Run on a device / emulator
```
Run → Run 'app'   (Shift+F10)
```

### Build a debug APK
```
Build → Build Bundle(s) / APK(s) → Build APK(s)
```
Output: `app/build/outputs/apk/debug/app-debug.apk`

### Build a release APK (command line)
```bash
./gradlew assembleRelease
```
> You must configure a signing keystore first — see Android Studio's  
> **Build → Generate Signed Bundle / APK** wizard.

---

## Step 5 — Enter your Gemini API key in the app

1. Install and open the app.  
2. Create an account or log in.  
3. Tap the **☰ menu → Settings**.  
4. Paste your Gemini API key and tap **Save**.  
5. Start chatting!

---

## Features

- **Native Compose UI** — no WebView; all screens are native Kotlin/Jetpack Compose.  
- **Supabase auth** — email/password sign-up, sign-in, and password reset.  
- **Persistent chat history** — all conversations saved to Supabase Postgres.  
- **Google Gemini 2.0 Flash** — fast, accurate AI responses.  
- **Markdown rendering** — bold, inline code, code blocks, headers, lists.  
- **English + Persian (فارسی) i18n** — full RTL support for Persian.  
- **Animated splash screen** — uses the AndroidX SplashScreen API.  
- **Adaptive launcher icon** — gradient navy-to-cyan with white M lettermark.  
- **Offline-aware** — shows errors when there's no network instead of crashing.  
- **Back-button handling** — closes the drawer before navigating back.

---

## Architecture

```
Activity / Composable
        ↓
   ViewModel  (Android Architecture Components)
        ↓
  Repository  (single source of truth)
        ↓
Retrofit / OkHttp  (network)   +   DataStore  (local)
        ↓                               ↓
  Supabase REST API            Encrypted preferences
  Gemini REST API
```

---

## Troubleshooting

| Symptom | Fix |
|---------|-----|
| Gradle sync fails | File → Invalidate Caches → Restart |
| "NO_API_KEY" dialog | Go to Settings and paste your Gemini API key |
| Login fails | Check network; Supabase project may need email confirmation disabled |
| Build error: `java.lang.NullPointerException` in DataStore | Clean project: Build → Clean Project, then rebuild |
| Icons missing | Re-run `Build → Clean Project`; the `mipmap-*` PNGs should appear in res/ |

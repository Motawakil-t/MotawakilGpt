package com.motawakilgpt.app.ui.activities

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.motawakilgpt.app.ui.*
import com.motawakilgpt.app.ui.viewmodels.SettingsViewModel
import com.motawakilgpt.app.utils.I18n

class SettingsActivity : ComponentActivity() {

    private val viewModel: SettingsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MotawakilGPTTheme {
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()

                LaunchedEffect(uiState.isSaved) {
                    if (uiState.isSaved) {
                        kotlinx.coroutines.delay(1500)
                        viewModel.clearSaved()
                    }
                }

                SettingsScreen(
                    apiKey = uiState.apiKey,
                    language = uiState.language,
                    isSaved = uiState.isSaved,
                    onSaveApiKey = { viewModel.saveApiKey(it) },
                    onLanguageChange = {
                        viewModel.setLanguage(it)
                        I18n.setLanguage(it)
                    },
                    onBack = { finish() }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    apiKey: String,
    language: String,
    isSaved: Boolean,
    onSaveApiKey: (String) -> Unit,
    onLanguageChange: (String) -> Unit,
    onBack: () -> Unit
) {
    var apiKeyInput by remember(apiKey) { mutableStateOf(apiKey) }
    var showApiKey by remember { mutableStateOf(false) }
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8F9FF))
    ) {
        // Top bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    tint = MotawakilColors.Foreground
                )
            }
            Text(
                text = I18n.t("settings"),
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                color = MotawakilColors.Foreground,
                modifier = Modifier.padding(start = 4.dp)
            )
        }
        Divider(color = MotawakilColors.Border)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // ─── Gemini API Key ───
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = I18n.t("api_key_label"),
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp,
                    color = MotawakilColors.Foreground
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = I18n.t("get_api_key"),
                    fontSize = 12.sp,
                    color = MotawakilColors.BrandAzure,
                    modifier = Modifier.clickable {
                        context.startActivity(
                            Intent(
                                Intent.ACTION_VIEW,
                                Uri.parse("https://aistudio.google.com/apikey")
                            )
                        )
                    }
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = apiKeyInput,
                    onValueChange = { apiKeyInput = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = {
                        Text(
                            I18n.t("api_key_hint"),
                            color = MotawakilColors.MutedForeground,
                            fontSize = 13.sp
                        )
                    },
                    visualTransformation = if (showApiKey) VisualTransformation.None
                    else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    trailingIcon = {
                        IconButton(onClick = { showApiKey = !showApiKey }) {
                            Icon(
                                imageVector = if (showApiKey) Icons.Default.VisibilityOff
                                else Icons.Default.Visibility,
                                contentDescription = null,
                                tint = MotawakilColors.MutedForeground
                            )
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MotawakilColors.BrandAzure,
                        unfocusedBorderColor = MotawakilColors.Border
                    )
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GradientButton(
                        text = I18n.t("save"),
                        onClick = { onSaveApiKey(apiKeyInput) },
                        modifier = Modifier.weight(1f)
                    )
                    if (isSaved) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = Color(0xFF2E7D32),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = I18n.t("api_key_saved"),
                            fontSize = 13.sp,
                            color = Color(0xFF2E7D32)
                        )
                    }
                }
            }

            // ─── Language ───
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = I18n.t("language"),
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp,
                    color = MotawakilColors.Foreground
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    LanguageOption(
                        label = I18n.t("english"),
                        isSelected = language == "en",
                        onClick = { onLanguageChange("en") },
                        modifier = Modifier.weight(1f)
                    )
                    LanguageOption(
                        label = I18n.t("persian"),
                        isSelected = language == "fa",
                        onClick = { onLanguageChange("fa") },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // ─── About ───
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "About",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp,
                    color = MotawakilColors.Foreground
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "MotawakilGPT v1.0",
                    fontSize = 13.sp,
                    color = MotawakilColors.MutedForeground
                )
                Text(
                    text = "Powered by Google Gemini & Supabase",
                    fontSize = 12.sp,
                    color = MotawakilColors.MutedForeground
                )
            }
        }
    }
}

@Composable
fun LanguageOption(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(
                if (isSelected) BrandGradient
                else androidx.compose.ui.graphics.Brush.linearGradient(
                    listOf(Color(0xFFF0F2FF), Color(0xFFF0F2FF))
                )
            )
            .border(
                1.dp,
                if (isSelected) Color.Transparent else MotawakilColors.Border,
                RoundedCornerShape(10.dp)
            )
            .clickable { onClick() }
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 14.sp,
            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
            color = if (isSelected) Color.White else MotawakilColors.Foreground
        )
    }
}

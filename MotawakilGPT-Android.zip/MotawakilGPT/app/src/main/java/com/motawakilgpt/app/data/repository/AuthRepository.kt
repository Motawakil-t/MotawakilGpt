package com.motawakilgpt.app.data.repository

import com.motawakilgpt.app.data.models.*
import com.motawakilgpt.app.network.RetrofitClient
import com.motawakilgpt.app.utils.SessionManager
import com.motawakilgpt.app.utils.bearerToken
import kotlinx.coroutines.flow.first

sealed class Result<out T> {
    data class Success<T>(val data: T) : Result<T>()
    data class Error(val message: String) : Result<Nothing>()
}

class AuthRepository(private val sessionManager: SessionManager) {

    private val authService = RetrofitClient.supabaseAuthService

    suspend fun signUp(email: String, password: String): Result<User> {
        return try {
            val response = authService.signUp(SignUpRequest(email, password))
            if (response.isSuccessful) {
                val body = response.body()
                val user = body?.user
                val session = body?.session
                if (user != null && session != null) {
                    val u = User(id = user.id, email = user.email ?: email)
                    sessionManager.saveSession(session.accessToken, session.refreshToken, u)
                    Result.Success(u)
                } else {
                    Result.Error("Registration successful. Please check your email to verify.")
                }
            } else {
                val errBody = response.errorBody()?.string() ?: ""
                Result.Error(parseSupabaseError(errBody))
            }
        } catch (e: Exception) {
            Result.Error(e.message ?: "Network error")
        }
    }

    suspend fun signIn(email: String, password: String): Result<User> {
        return try {
            val response = authService.signIn(SignInRequest(email, password))
            if (response.isSuccessful) {
                val body = response.body()
                val user = body?.user
                val session = body?.session
                if (user != null && session != null) {
                    val u = User(id = user.id, email = user.email ?: email)
                    sessionManager.saveSession(session.accessToken, session.refreshToken, u)
                    Result.Success(u)
                } else {
                    Result.Error("Sign in failed")
                }
            } else {
                val errBody = response.errorBody()?.string() ?: ""
                Result.Error(parseSupabaseError(errBody))
            }
        } catch (e: Exception) {
            Result.Error(e.message ?: "Network error")
        }
    }

    suspend fun signOut(): Result<Unit> {
        return try {
            val token = sessionManager.accessToken.first()
            if (token != null) {
                authService.signOut(bearerToken(token))
            }
            sessionManager.clearSession()
            Result.Success(Unit)
        } catch (e: Exception) {
            sessionManager.clearSession()
            Result.Success(Unit)
        }
    }

    suspend fun resetPassword(email: String): Result<Unit> {
        return try {
            val response = authService.resetPassword(mapOf("email" to email))
            if (response.isSuccessful) {
                Result.Success(Unit)
            } else {
                Result.Error("Failed to send reset email")
            }
        } catch (e: Exception) {
            Result.Error(e.message ?: "Network error")
        }
    }

    suspend fun getCurrentUser(): User? {
        return try {
            val token = sessionManager.accessToken.first() ?: return null
            val email = sessionManager.userEmail.first() ?: return null
            val id = sessionManager.userId.first() ?: return null
            User(id = id, email = email)
        } catch (e: Exception) {
            null
        }
    }

    suspend fun isLoggedIn(): Boolean {
        return sessionManager.accessToken.first() != null
    }

    private fun parseSupabaseError(body: String): String {
        return try {
            val gson = com.google.gson.Gson()
            val err = gson.fromJson(body, SupabaseError::class.java)
            err.message ?: err.errorDescription ?: err.error ?: "Unknown error"
        } catch (e: Exception) {
            "Authentication failed"
        }
    }
}

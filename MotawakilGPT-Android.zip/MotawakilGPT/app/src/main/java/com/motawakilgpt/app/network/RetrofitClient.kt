package com.motawakilgpt.app.network

import com.motawakilgpt.app.BuildConfig
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object RetrofitClient {

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BODY
        else HttpLoggingInterceptor.Level.NONE
    }

    private val baseOkHttpClient: OkHttpClient = OkHttpClient.Builder()
        .addInterceptor(loggingInterceptor)
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    // Supabase base URL
    private val supabaseRetrofit: Retrofit = Retrofit.Builder()
        .baseUrl(BuildConfig.SUPABASE_URL + "/")
        .client(baseOkHttpClient)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    // Gemini API base URL
    private val geminiRetrofit: Retrofit = Retrofit.Builder()
        .baseUrl("https://generativelanguage.googleapis.com/")
        .client(baseOkHttpClient)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    val supabaseAuthService: SupabaseAuthService by lazy {
        supabaseRetrofit.create(SupabaseAuthService::class.java)
    }

    val supabaseDbService: SupabaseDbService by lazy {
        supabaseRetrofit.create(SupabaseDbService::class.java)
    }

    val geminiApiService: GeminiApiService by lazy {
        geminiRetrofit.create(GeminiApiService::class.java)
    }
}

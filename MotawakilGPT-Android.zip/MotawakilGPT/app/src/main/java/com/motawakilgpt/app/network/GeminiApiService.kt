package com.motawakilgpt.app.network

import com.motawakilgpt.app.data.models.GeminiRequest
import com.motawakilgpt.app.data.models.GeminiResponse
import retrofit2.Response
import retrofit2.http.*

interface GeminiApiService {

    @POST("v1beta/models/gemini-2.0-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): Response<GeminiResponse>
}

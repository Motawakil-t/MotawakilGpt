package com.motawakilgpt.app.ui.activities

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Message
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.motawakilgpt.app.ui.*
import com.motawakilgpt.app.utils.I18n

class LandingActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MotawakilGPTTheme {
                LandingScreen(
                    onLogin = {
                        startActivity(
                            Intent(this, AuthActivity::class.java)
                                .putExtra("mode", "login")
                        )
                    },
                    onGetStarted = {
                        startActivity(
                            Intent(this, AuthActivity::class.java)
                                .putExtra("mode", "signup")
                        )
                    }
                )
            }
        }
    }
}

@Composable
fun LandingScreen(onLogin: () -> Unit, onGetStarted: () -> Unit) {
    val scrollState = rememberScrollState()
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8F9FF))
            .verticalScroll(scrollState)
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            BrandMark(size = 32.dp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = onLogin) {
                    Text(
                        I18n.t("login"),
                        color = MotawakilColors.Foreground,
                        fontWeight = FontWeight.Medium
                    )
                }
                GradientButton(
                    text = I18n.t("get_started"),
                    onClick = onGetStarted,
                    modifier = Modifier.width(120.dp)
                )
            }
        }

        // Hero Section
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .padding(top = 32.dp, bottom = 40.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            LogoImage(size = 120.dp)
            Spacer(modifier = Modifier.height(24.dp))

            // Badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(Color(0xFFF0F2FF))
                    .border(1.dp, MotawakilColors.Border, RoundedCornerShape(50))
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Text(
                    text = I18n.t("hero_badge"),
                    fontSize = 12.sp,
                    color = MotawakilColors.MutedForeground
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = I18n.t("hero_title_a") + " ",
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = MotawakilColors.Foreground,
                textAlign = TextAlign.Center
            )
            // Gradient title
            Text(
                text = I18n.t("hero_title_b"),
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                color = MotawakilColors.BrandAzure
            )

            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = I18n.t("hero_desc"),
                fontSize = 15.sp,
                color = MotawakilColors.MutedForeground,
                textAlign = TextAlign.Center,
                lineHeight = 22.sp,
                modifier = Modifier.fillMaxWidth(0.9f)
            )

            Spacer(modifier = Modifier.height(28.dp))
            GradientButton(
                text = I18n.t("get_started_free"),
                onClick = onGetStarted,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(12.dp))
            OutlineButton(
                text = I18n.t("login"),
                onClick = onLogin,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Features
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            LandingFeatureCard(
                icon = Icons.Default.Message,
                title = I18n.t("feature_stream_title"),
                description = I18n.t("feature_stream_desc")
            )
            LandingFeatureCard(
                icon = Icons.Default.Lock,
                title = I18n.t("feature_private_title"),
                description = I18n.t("feature_private_desc")
            )
            LandingFeatureCard(
                icon = Icons.Default.History,
                title = I18n.t("feature_history_title"),
                description = I18n.t("feature_history_desc")
            )
        }

        // Footer
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "© 2025 ${I18n.t("app_name")}. ${I18n.t("footer_rights")}",
                fontSize = 12.sp,
                color = MotawakilColors.MutedForeground,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun LandingFeatureCard(icon: ImageVector, title: String, description: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White.copy(alpha = 0.8f))
            .border(1.dp, MotawakilColors.Border, RoundedCornerShape(16.dp))
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(BrandGradient),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(20.dp)
            )
        }
        Column {
            Text(
                text = title,
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp,
                color = MotawakilColors.Foreground
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = description,
                fontSize = 13.sp,
                color = MotawakilColors.MutedForeground,
                lineHeight = 18.sp
            )
        }
    }
}

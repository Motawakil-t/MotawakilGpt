package com.motawakilgpt.app.ui.viewmodels

import android.app.Application
import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.motawakilgpt.app.utils.I18n
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "motawakil_settings")

data class SettingsUiState(
    val apiKey: String = "",
    val language: String = "en",
    val isSaved: Boolean = false
)

class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        val GEMINI_API_KEY = stringPreferencesKey("gemini_api_key")
        val LANGUAGE_KEY = stringPreferencesKey("language")
    }

    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    private val dataStore = application.settingsDataStore

    init {
        loadSettings()
    }

    private fun loadSettings() {
        viewModelScope.launch {
            val prefs = dataStore.data.first()
            val apiKey = prefs[GEMINI_API_KEY] ?: ""
            val language = prefs[LANGUAGE_KEY] ?: "en"
            I18n.setLanguage(language)
            _uiState.value = SettingsUiState(apiKey = apiKey, language = language)
        }
    }

    fun saveApiKey(apiKey: String) {
        viewModelScope.launch {
            dataStore.edit { prefs ->
                prefs[GEMINI_API_KEY] = apiKey.trim()
            }
            _uiState.value = _uiState.value.copy(apiKey = apiKey.trim(), isSaved = true)
        }
    }

    fun setLanguage(lang: String) {
        viewModelScope.launch {
            dataStore.edit { prefs ->
                prefs[LANGUAGE_KEY] = lang
            }
            I18n.setLanguage(lang)
            _uiState.value = _uiState.value.copy(language = lang)
        }
    }

    fun clearSaved() {
        _uiState.value = _uiState.value.copy(isSaved = false)
    }

    suspend fun getApiKey(): String {
        val prefs = dataStore.data.first()
        return prefs[GEMINI_API_KEY] ?: ""
    }

    suspend fun getLanguage(): String {
        val prefs = dataStore.data.first()
        return prefs[LANGUAGE_KEY] ?: "en"
    }
}

package com.motawakilgpt.app.ui.activities

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.motawakilgpt.app.data.models.Message
import com.motawakilgpt.app.ui.*
import com.motawakilgpt.app.ui.viewmodels.ChatViewModel
import com.motawakilgpt.app.utils.I18n
import kotlinx.coroutines.launch

@Composable
fun ChatWindow(chatViewModel: ChatViewModel) {
    val chatUiState by chatViewModel.chatUiState.collectAsStateWithLifecycle()
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val clipboardManager = LocalClipboardManager.current
    var copiedId by remember { mutableStateOf<String?>(null) }
    var showApiKeyDialog by remember { mutableStateOf(false) }

    // Scroll to bottom on new messages
    LaunchedEffect(chatUiState.messages.size, chatUiState.isGenerating) {
        if (chatUiState.messages.isNotEmpty()) {
            scope.launch {
                listState.animateScrollToItem(chatUiState.messages.size - 1 +
                        if (chatUiState.isGenerating) 1 else 0)
            }
        }
    }

    // Handle error
    LaunchedEffect(chatUiState.error) {
        if (chatUiState.error == "NO_API_KEY") {
            showApiKeyDialog = true
            chatViewModel.clearError()
        }
    }

    if (showApiKeyDialog) {
        ApiKeyDialog(
            onDismiss = { showApiKeyDialog = false }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        // Messages area
        Box(modifier = Modifier.weight(1f)) {
            if (chatUiState.messages.isEmpty() && !chatUiState.isGenerating) {
                // Empty state
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    LogoImage(size = 80.dp)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = I18n.t("how_can_i_help"),
                        fontSize = 22.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MotawakilColors.Foreground,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = I18n.t("empty_subtitle"),
                        fontSize = 13.sp,
                        color = MotawakilColors.MutedForeground,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 8.dp)
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // Suggestion chips
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val suggestions = listOf(
                            I18n.t("s1"), I18n.t("s2"), I18n.t("s3"), I18n.t("s4")
                        )
                        suggestions.chunked(2).forEach { row ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                row.forEach { suggestion ->
                                    SuggestionChip(
                                        text = suggestion,
                                        onClick = { inputText = suggestion },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                // Fill remaining space if row has 1 item
                                if (row.size < 2) {
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(chatUiState.messages) { message ->
                        MessageBubble(
                            message = message,
                            onCopy = { text ->
                                clipboardManager.setText(AnnotatedString(text))
                                copiedId = message.id ?: message.content.hashCode().toString()
                            },
                            isCopied = copiedId == (message.id ?: message.content.hashCode().toString())
                        )
                    }
                    if (chatUiState.isGenerating) {
                        item {
                            ThinkingBubble()
                        }
                    }
                }
            }

            // Error snackbar
            if (chatUiState.error != null && chatUiState.error != "NO_API_KEY") {
                Snackbar(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(16.dp),
                    action = {
                        TextButton(onClick = { chatViewModel.clearError() }) {
                            Text("OK", color = Color.White)
                        }
                    }
                ) {
                    Text(chatUiState.error ?: "")
                }
            }
        }

        // Input area
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
        ) {
            Divider(color = MotawakilColors.Border)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFFF8F9FF))
                    .border(1.dp, MotawakilColors.Border, RoundedCornerShape(16.dp))
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                TextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    modifier = Modifier.weight(1f),
                    placeholder = {
                        Text(
                            I18n.t("message_placeholder"),
                            color = MotawakilColors.MutedForeground,
                            fontSize = 14.sp
                        )
                    },
                    maxLines = 6,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        disabledIndicatorColor = Color.Transparent
                    )
                )
                if (chatUiState.isGenerating) {
                    IconButton(onClick = { /* stop not implemented for non-streaming */ }) {
                        Icon(
                            imageVector = Icons.Default.Stop,
                            contentDescription = I18n.t("stop"),
                            tint = MotawakilColors.Foreground
                        )
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (inputText.isNotBlank()) BrandGradient
                                else Brush.linearGradient(
                                    listOf(Color(0xFFE0E0E0), Color(0xFFE0E0E0))
                                )
                            )
                            .clickable(enabled = inputText.isNotBlank()) {
                                chatViewModel.sendMessage(inputText)
                                inputText = ""
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowUpward,
                            contentDescription = I18n.t("send"),
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
            Text(
                text = I18n.t("disclaimer"),
                fontSize = 11.sp,
                color = MotawakilColors.MutedForeground,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            )
        }
    }
}

@Composable
fun MessageBubble(message: Message, onCopy: (String) -> Unit, isCopied: Boolean) {
    val isUser = message.role == "user"

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Top
    ) {
        if (!isUser) {
            // AI avatar
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(BrandGradient),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
        }

        Column(
            modifier = Modifier.widthIn(max = 300.dp),
            horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
        ) {
            SelectionContainer {
                Box(
                    modifier = Modifier
                        .clip(
                            RoundedCornerShape(
                                topStart = if (isUser) 16.dp else 4.dp,
                                topEnd = if (isUser) 4.dp else 16.dp,
                                bottomStart = 16.dp,
                                bottomEnd = 16.dp
                            )
                        )
                        .background(
                            if (isUser) BrandGradient
                            else Brush.linearGradient(listOf(Color(0xFFF0F2FF), Color(0xFFF0F2FF)))
                        )
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    if (isUser) {
                        Text(
                            text = message.content,
                            color = Color.White,
                            fontSize = 14.sp,
                            lineHeight = 20.sp
                        )
                    } else {
                        MarkdownText(text = message.content)
                    }
                }
            }

            if (!isUser) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .clickable { onCopy(message.content) }
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = if (isCopied) Icons.Default.Check else Icons.Default.ContentCopy,
                        contentDescription = null,
                        tint = MotawakilColors.MutedForeground,
                        modifier = Modifier.size(12.dp)
                    )
                    Text(
                        text = if (isCopied) I18n.t("copied") else I18n.t("copy"),
                        fontSize = 11.sp,
                        color = MotawakilColors.MutedForeground
                    )
                }
            }
        }

        if (isUser) {
            Spacer(modifier = Modifier.width(8.dp))
            // User avatar
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFE8EAFF)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = null,
                    tint = MotawakilColors.BrandAzure,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun ThinkingBubble() {
    Row(
        horizontalArrangement = Arrangement.Start,
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(BrandGradient),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(16.dp)
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(4.dp, 16.dp, 16.dp, 16.dp))
                .background(Color(0xFFF0F2FF))
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TypingIndicator()
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = I18n.t("thinking"),
                    fontSize = 13.sp,
                    color = MotawakilColors.MutedForeground
                )
            }
        }
    }
}

@Composable
fun SuggestionChip(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFFF0F2FF))
            .border(1.dp, MotawakilColors.Border, RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Text(
            text = text,
            fontSize = 12.sp,
            color = MotawakilColors.MutedForeground,
            lineHeight = 16.sp
        )
    }
}

@Composable
fun MarkdownText(text: String) {
    // Simple markdown rendering for Android
    // Handles: bold (**text**), code (inline `code` and blocks ```code```), headers, lists
    val lines = text.split("\n")
    Column {
        var i = 0
        while (i < lines.size) {
            val line = lines[i]
            when {
                // Code block
                line.startsWith("```") -> {
                    val codeLines = mutableListOf<String>()
                    i++
                    while (i < lines.size && !lines[i].startsWith("```")) {
                        codeLines.add(lines[i])
                        i++
                    }
                    CodeBlock(code = codeLines.joinToString("\n"))
                }
                // H1
                line.startsWith("# ") -> {
                    Text(
                        text = line.removePrefix("# "),
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = MotawakilColors.Foreground
                    )
                }
                // H2
                line.startsWith("## ") -> {
                    Text(
                        text = line.removePrefix("## "),
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MotawakilColors.Foreground
                    )
                }
                // H3
                line.startsWith("### ") -> {
                    Text(
                        text = line.removePrefix("### "),
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp,
                        color = MotawakilColors.Foreground
                    )
                }
                // Bullet list
                line.startsWith("- ") || line.startsWith("* ") -> {
                    Row(modifier = Modifier.padding(start = 8.dp)) {
                        Text("• ", color = MotawakilColors.MutedForeground, fontSize = 14.sp)
                        InlineMarkdownText(text = line.drop(2))
                    }
                }
                // Numbered list
                line.matches(Regex("^\\d+\\..*")) -> {
                    Row(modifier = Modifier.padding(start = 8.dp)) {
                        val num = line.substringBefore(".")
                        Text("$num. ", color = MotawakilColors.MutedForeground, fontSize = 14.sp)
                        InlineMarkdownText(text = line.substringAfter(". "))
                    }
                }
                // Regular line
                line.isNotBlank() -> {
                    InlineMarkdownText(text = line)
                }
                // Empty line
                else -> {
                    Spacer(modifier = Modifier.height(4.dp))
                }
            }
            i++
        }
    }
}

@Composable
fun InlineMarkdownText(text: String) {
    // Build annotated string for inline bold and code
    val annotated = buildInlineMarkdown(text)
    Text(
        text = annotated,
        fontSize = 14.sp,
        color = MotawakilColors.Foreground,
        lineHeight = 20.sp
    )
}

fun buildInlineMarkdown(text: String): AnnotatedString {
    return androidx.compose.ui.text.buildAnnotatedString {
        var i = 0
        while (i < text.length) {
            when {
                // Bold **text**
                text.startsWith("**", i) -> {
                    val end = text.indexOf("**", i + 2)
                    if (end != -1) {
                        pushStyle(
                            androidx.compose.ui.text.SpanStyle(fontWeight = FontWeight.Bold)
                        )
                        append(text.substring(i + 2, end))
                        pop()
                        i = end + 2
                    } else {
                        append(text[i])
                        i++
                    }
                }
                // Inline code `text`
                text[i] == '`' -> {
                    val end = text.indexOf('`', i + 1)
                    if (end != -1) {
                        pushStyle(
                            androidx.compose.ui.text.SpanStyle(
                                fontFamily = FontFamily.Monospace,
                                background = Color(0xFFEBEEFF),
                                fontSize = 12.sp
                            )
                        )
                        append(text.substring(i + 1, end))
                        pop()
                        i = end + 1
                    } else {
                        append(text[i])
                        i++
                    }
                }
                else -> {
                    append(text[i])
                    i++
                }
            }
        }
    }
}

@Composable
fun CodeBlock(code: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFFF0F2FF))
            .border(1.dp, MotawakilColors.Border, RoundedCornerShape(8.dp))
            .padding(12.dp)
    ) {
        SelectionContainer {
            Text(
                text = code,
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp,
                color = MotawakilColors.Foreground,
                lineHeight = 18.sp
            )
        }
    }
}

@Composable
fun ApiKeyDialog(onDismiss: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(I18n.t("no_api_key")) },
        text = {
            Column {
                Text(I18n.t("api_key_hint"), fontSize = 13.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    I18n.t("get_api_key"),
                    fontSize = 12.sp,
                    color = MotawakilColors.BrandAzure,
                    modifier = Modifier.clickable {
                        (context as? android.app.Activity)?.let {
                            it.startActivity(
                                android.content.Intent(
                                    android.content.Intent.ACTION_VIEW,
                                    android.net.Uri.parse("https://aistudio.google.com/apikey")
                                )
                            )
                        }
                    }
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onDismiss()
                // Open settings
                (context as? android.app.Activity)?.startActivity(
                    android.content.Intent(context, SettingsActivity::class.java)
                )
            }) {
                Text(I18n.t("settings"), color = MotawakilColors.BrandAzure)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(I18n.t("cancel"))
            }
        }
    )
}

package com.motawakilgpt.app.ui.activities

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.motawakilgpt.app.ui.*
import com.motawakilgpt.app.ui.viewmodels.AuthViewModel
import com.motawakilgpt.app.utils.I18n

class AuthActivity : ComponentActivity() {

    private val viewModel: AuthViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val initialMode = intent.getStringExtra("mode") ?: "login"

        setContent {
            MotawakilGPTTheme {
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()

                // Navigate to main when logged in
                LaunchedEffect(uiState.isLoggedIn) {
                    if (uiState.isLoggedIn) {
                        startActivity(Intent(this@AuthActivity, MainActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        })
                        finish()
                    }
                }

                AuthScreen(
                    initialMode = initialMode,
                    isLoading = uiState.isLoading,
                    error = uiState.error,
                    successMessage = uiState.successMessage,
                    onSignIn = { email, password -> viewModel.signIn(email, password) },
                    onSignUp = { email, password -> viewModel.signUp(email, password) },
                    onResetPassword = { email -> viewModel.resetPassword(email) },
                    onClearError = { viewModel.clearError() },
                    onBack = { finish() }
                )
            }
        }
    }
}

@Composable
fun AuthScreen(
    initialMode: String,
    isLoading: Boolean,
    error: String?,
    successMessage: String?,
    onSignIn: (String, String) -> Unit,
    onSignUp: (String, String) -> Unit,
    onResetPassword: (String) -> Unit,
    onClearError: () -> Unit,
    onBack: () -> Unit
) {
    var mode by remember { mutableStateOf(initialMode) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    val isSignup = mode == "signup"

    // Clear error on mode switch
    LaunchedEffect(mode) { onClearError() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8F9FF))
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(40.dp))

        // Logo
        LogoImage(size = 72.dp)
        Spacer(modifier = Modifier.height(8.dp))
        BrandMark(size = 28.dp)
        Spacer(modifier = Modifier.height(32.dp))

        // Card
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = if (isSignup) I18n.t("create_account") else I18n.t("welcome_back"),
                fontSize = 22.sp,
                fontWeight = FontWeight.SemiBold,
                color = MotawakilColors.Foreground
            )
            Text(
                text = if (isSignup) I18n.t("signup_subtitle") else I18n.t("signin_subtitle"),
                fontSize = 13.sp,
                color = MotawakilColors.MutedForeground,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Email field
            Text(
                text = I18n.t("email"),
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = MotawakilColors.Foreground
            )
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = email,
                onValueChange = { email = it; onClearError() },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("you@example.com", color = MotawakilColors.MutedForeground) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                singleLine = true,
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MotawakilColors.BrandAzure,
                    unfocusedBorderColor = MotawakilColors.Border
                )
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Password field
            Text(
                text = I18n.t("password"),
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = MotawakilColors.Foreground
            )
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = password,
                onValueChange = { password = it; onClearError() },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("••••••••", color = MotawakilColors.MutedForeground) },
                visualTransformation = if (passwordVisible) VisualTransformation.None
                else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                singleLine = true,
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MotawakilColors.BrandAzure,
                    unfocusedBorderColor = MotawakilColors.Border
                )
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Show/hide password toggle
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(
                    onClick = { passwordVisible = !passwordVisible },
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text(
                        text = if (passwordVisible) "Hide" else "Show",
                        fontSize = 12.sp,
                        color = MotawakilColors.BrandAzure
                    )
                }
            }

            // Error
            if (error != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = error,
                    color = MotawakilColors.Destructive,
                    fontSize = 13.sp
                )
            }

            // Success
            if (successMessage != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = successMessage,
                    color = Color(0xFF2E7D32),
                    fontSize = 13.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            GradientButton(
                text = if (isLoading) I18n.t("please_wait")
                else if (isSignup) I18n.t("create_account_btn")
                else I18n.t("sign_in"),
                onClick = {
                    if (isSignup) onSignUp(email, password)
                    else onSignIn(email, password)
                },
                modifier = Modifier.fillMaxWidth(),
                isLoading = isLoading,
                enabled = !isLoading
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Forgot password (login only)
            if (!isSignup) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = I18n.t("forgot_password"),
                        fontSize = 13.sp,
                        color = MotawakilColors.MutedForeground,
                        modifier = Modifier.clickable {
                            if (email.isNotBlank()) onResetPassword(email)
                        }
                    )
                    Text(
                        text = I18n.t("no_account"),
                        fontSize = 13.sp,
                        color = MotawakilColors.BrandAzure,
                        modifier = Modifier.clickable { mode = "signup"; onClearError() }
                    )
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = I18n.t("have_account"),
                        fontSize = 13.sp,
                        color = MotawakilColors.BrandAzure,
                        modifier = Modifier.clickable { mode = "login"; onClearError() }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))
        TextButton(onClick = onBack) {
            Text("← Back", color = MotawakilColors.MutedForeground)
        }
    }
}

package com.motawakilgpt.app.data.models

import com.google.gson.annotations.SerializedName

data class User(
    val id: String,
    val email: String,
    val createdAt: String? = null
)

data class AuthState(
    val isAuthenticated: Boolean = false,
    val user: User? = null,
    val token: String? = null
)

data class Chat(
    val id: String,
    val title: String,
    @SerializedName("user_id") val userId: String,
    @SerializedName("updated_at") val updatedAt: String,
    @SerializedName("created_at") val createdAt: String? = null
)

data class Message(
    val id: String? = null,
    @SerializedName("chat_id") val chatId: String,
    @SerializedName("user_id") val userId: String? = null,
    val role: String,  // "user" | "assistant"
    val content: String,
    @SerializedName("created_at") val createdAt: String? = null
)

// API request/response models

data class SignUpRequest(
    val email: String,
    val password: String
)

data class SignInRequest(
    val email: String,
    val password: String
)

data class AuthResponse(
    val user: SupabaseUser?,
    val session: SupabaseSession?
)

data class SupabaseUser(
    val id: String,
    val email: String?,
    @SerializedName("created_at") val createdAt: String?
)

data class SupabaseSession(
    @SerializedName("access_token") val accessToken: String,
    @SerializedName("refresh_token") val refreshToken: String,
    @SerializedName("expires_in") val expiresIn: Int
)

data class SupabaseError(
    val error: String?,
    @SerializedName("error_description") val errorDescription: String?,
    val message: String?,
    val code: String?
)

data class InsertChatRequest(
    @SerializedName("user_id") val userId: String,
    val title: String
)

data class InsertMessageRequest(
    @SerializedName("chat_id") val chatId: String,
    @SerializedName("user_id") val userId: String,
    val role: String,
    val content: String
)

data class ChatCompletionRequest(
    val model: String = "claude-sonnet-4-6",
    val messages: List<ChatMessage>,
    val stream: Boolean = false,
    @SerializedName("max_tokens") val maxTokens: Int = 4096
)

data class ChatMessage(
    val role: String,
    val content: String
)

data class ChatCompletionResponse(
    val id: String?,
    val content: List<ContentBlock>?,
    val choices: List<Choice>?
)

data class ContentBlock(
    val type: String,
    val text: String?
)

data class Choice(
    val message: ChatMessage?,
    val delta: ChatMessage?
)

// Gemini API models
data class GeminiRequest(
    val contents: List<GeminiContent>,
    @SerializedName("systemInstruction") val systemInstruction: GeminiContent? = null,
    @SerializedName("generationConfig") val generationConfig: GeminiGenerationConfig? = null
)

data class GeminiContent(
    val role: String? = null,
    val parts: List<GeminiPart>
)

data class GeminiPart(
    val text: String
)

data class GeminiGenerationConfig(
    @SerializedName("maxOutputTokens") val maxOutputTokens: Int = 8192,
    val temperature: Float = 1.0f,
    @SerializedName("topP") val topP: Float = 0.95f
)

data class GeminiResponse(
    val candidates: List<GeminiCandidate>?,
    val error: GeminiError?
)

data class GeminiCandidate(
    val content: GeminiContent?,
    @SerializedName("finishReason") val finishReason: String?
)

data class GeminiError(
    val code: Int,
    val message: String,
    val status: String
)

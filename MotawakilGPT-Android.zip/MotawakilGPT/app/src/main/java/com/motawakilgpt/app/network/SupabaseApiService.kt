package com.motawakilgpt.app.network

import com.motawakilgpt.app.data.models.*
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.*

interface SupabaseAuthService {

    @POST("auth/v1/signup")
    suspend fun signUp(
        @Body request: SignUpRequest
    ): Response<AuthResponse>

    @POST("auth/v1/token?grant_type=password")
    suspend fun signIn(
        @Body request: SignInRequest
    ): Response<AuthResponse>

    @POST("auth/v1/logout")
    suspend fun signOut(
        @Header("Authorization") token: String
    ): Response<ResponseBody>

    @GET("auth/v1/user")
    suspend fun getUser(
        @Header("Authorization") token: String
    ): Response<SupabaseUser>

    @POST("auth/v1/recover")
    suspend fun resetPassword(
        @Body body: Map<String, String>
    ): Response<ResponseBody>
}

interface SupabaseDbService {

    @GET("rest/v1/chats")
    suspend fun getChats(
        @Header("Authorization") token: String,
        @Query("select") select: String = "id,title,updated_at",
        @Query("order") order: String = "updated_at.desc"
    ): Response<List<Chat>>

    @POST("rest/v1/chats")
    @Headers("Prefer: return=representation")
    suspend fun insertChat(
        @Header("Authorization") token: String,
        @Body request: InsertChatRequest
    ): Response<List<Chat>>

    @PATCH("rest/v1/chats")
    suspend fun updateChat(
        @Header("Authorization") token: String,
        @Query("id") id: String,
        @Body body: Map<String, String>
    ): Response<ResponseBody>

    @DELETE("rest/v1/chats")
    suspend fun deleteChat(
        @Header("Authorization") token: String,
        @Query("id") id: String
    ): Response<ResponseBody>

    @GET("rest/v1/messages")
    suspend fun getMessages(
        @Header("Authorization") token: String,
        @Query("chat_id") chatId: String,
        @Query("select") select: String = "id,role,content,created_at",
        @Query("order") order: String = "created_at.asc"
    ): Response<List<Message>>

    @POST("rest/v1/messages")
    suspend fun insertMessage(
        @Header("Authorization") token: String,
        @Body request: InsertMessageRequest
    ): Response<ResponseBody>
}

package com.motawakilgpt.app.ui.viewmodels

import android.app.Application
import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.motawakilgpt.app.data.models.Chat
import com.motawakilgpt.app.data.models.Message
import com.motawakilgpt.app.data.repository.AIRepository
import com.motawakilgpt.app.data.repository.ChatRepository
import com.motawakilgpt.app.data.repository.Result
import com.motawakilgpt.app.utils.SessionManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

private val Context.chatViewModelDataStore: DataStore<Preferences> by preferencesDataStore(name = "motawakil_settings")

data class ChatListUiState(
    val isLoading: Boolean = false,
    val chats: List<Chat> = emptyList(),
    val error: String? = null
)

data class ChatUiState(
    val isLoading: Boolean = false,
    val messages: List<Message> = emptyList(),
    val isGenerating: Boolean = false,
    val currentChatId: String? = null,
    val error: String? = null,
    val userEmail: String = ""
)

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val sessionManager = SessionManager(application)
    private val chatRepository = ChatRepository(sessionManager)
    private val aiRepository = AIRepository(sessionManager)
    private val dataStore = application.chatViewModelDataStore

    private val GEMINI_API_KEY = stringPreferencesKey("gemini_api_key")

    private val _chatListState = MutableStateFlow(ChatListUiState())
    val chatListState: StateFlow<ChatListUiState> = _chatListState.asStateFlow()

    private val _chatUiState = MutableStateFlow(ChatUiState())
    val chatUiState: StateFlow<ChatUiState> = _chatUiState.asStateFlow()

    init {
        loadChats()
        loadUserEmail()
    }

    private fun loadUserEmail() {
        viewModelScope.launch {
            val email = sessionManager.userEmail.first() ?: ""
            _chatUiState.value = _chatUiState.value.copy(userEmail = email)
        }
    }

    fun loadChats() {
        viewModelScope.launch {
            _chatListState.value = _chatListState.value.copy(isLoading = true, error = null)
            when (val result = chatRepository.getChats()) {
                is Result.Success -> {
                    _chatListState.value = ChatListUiState(chats = result.data)
                }
                is Result.Error -> {
                    _chatListState.value = ChatListUiState(error = result.message)
                }
            }
        }
    }

    fun openChat(chatId: String) {
        viewModelScope.launch {
            _chatUiState.value = _chatUiState.value.copy(
                isLoading = true,
                currentChatId = chatId,
                messages = emptyList(),
                error = null
            )
            when (val result = chatRepository.getMessages(chatId)) {
                is Result.Success -> {
                    _chatUiState.value = _chatUiState.value.copy(
                        isLoading = false,
                        messages = result.data,
                        currentChatId = chatId
                    )
                }
                is Result.Error -> {
                    _chatUiState.value = _chatUiState.value.copy(
                        isLoading = false,
                        error = result.message
                    )
                }
            }
        }
    }

    fun newChat() {
        _chatUiState.value = ChatUiState(
            userEmail = _chatUiState.value.userEmail
        )
    }

    fun sendMessage(text: String) {
        viewModelScope.launch {
            val trimmed = text.trim()
            if (trimmed.isEmpty() || _chatUiState.value.isGenerating) return@launch

            val apiKey = getApiKey()

            // Create chat if needed
            var chatId = _chatUiState.value.currentChatId
            if (chatId == null) {
                val provisional = trimmed.take(60)
                when (val result = chatRepository.createChat(provisional)) {
                    is Result.Success -> {
                        chatId = result.data.id
                        _chatUiState.value = _chatUiState.value.copy(currentChatId = chatId)
                        loadChats()
                    }
                    is Result.Error -> {
                        _chatUiState.value = _chatUiState.value.copy(error = result.message)
                        return@launch
                    }
                }
            }

            val finalChatId = chatId ?: return@launch

            // Add user message locally
            val userMsg = Message(
                chatId = finalChatId,
                role = "user",
                content = trimmed
            )
            val updatedMessages = _chatUiState.value.messages + userMsg
            _chatUiState.value = _chatUiState.value.copy(
                messages = updatedMessages,
                isGenerating = true,
                error = null
            )

            // Persist user message
            chatRepository.insertMessage(finalChatId, "user", trimmed)

            // Call AI
            when (val result = aiRepository.generateResponse(updatedMessages, apiKey)) {
                is Result.Success -> {
                    val assistantMsg = Message(
                        chatId = finalChatId,
                        role = "assistant",
                        content = result.data
                    )
                    val finalMessages = _chatUiState.value.messages + assistantMsg
                    _chatUiState.value = _chatUiState.value.copy(
                        messages = finalMessages,
                        isGenerating = false
                    )
                    chatRepository.insertMessage(finalChatId, "assistant", result.data)
                    chatRepository.updateChatTimestamp(finalChatId)
                    loadChats()
                }
                is Result.Error -> {
                    _chatUiState.value = _chatUiState.value.copy(
                        isGenerating = false,
                        error = result.message
                    )
                }
            }
        }
    }

    fun deleteChat(chatId: String) {
        viewModelScope.launch {
            when (val result = chatRepository.deleteChat(chatId)) {
                is Result.Success -> {
                    if (_chatUiState.value.currentChatId == chatId) {
                        newChat()
                    }
                    loadChats()
                }
                is Result.Error -> {
                    _chatListState.value = _chatListState.value.copy(error = result.message)
                }
            }
        }
    }

    fun clearError() {
        _chatUiState.value = _chatUiState.value.copy(error = null)
    }

    private suspend fun getApiKey(): String {
        return try {
            val prefs = dataStore.data.first()
            prefs[GEMINI_API_KEY] ?: ""
        } catch (e: Exception) {
            ""
        }
    }
}

package com.motawakilgpt.app.data.repository

import com.motawakilgpt.app.data.models.*
import com.motawakilgpt.app.network.RetrofitClient
import com.motawakilgpt.app.utils.SessionManager
import kotlinx.coroutines.flow.first

class AIRepository(private val sessionManager: SessionManager) {

    private val geminiService = RetrofitClient.geminiApiService

    companion object {
        private const val SYSTEM_PROMPT =
            "You are MotawakilGPT, a helpful, concise, and friendly AI assistant powered by Google Gemini. " +
                    "Use Markdown formatting where appropriate. Be accurate and to the point."
    }

    suspend fun generateResponse(
        messages: List<Message>,
        apiKey: String
    ): Result<String> {
        return try {
            if (apiKey.isBlank()) {
                return Result.Error("NO_API_KEY")
            }

            // Convert messages to Gemini format
            val geminiContents = messages.map { msg ->
                GeminiContent(
                    role = if (msg.role == "user") "user" else "model",
                    parts = listOf(GeminiPart(text = msg.content))
                )
            }

            val request = GeminiRequest(
                contents = geminiContents,
                systemInstruction = GeminiContent(
                    parts = listOf(GeminiPart(text = SYSTEM_PROMPT))
                ),
                generationConfig = GeminiGenerationConfig(
                    maxOutputTokens = 8192,
                    temperature = 1.0f
                )
            )

            val response = geminiService.generateContent(
                apiKey = apiKey,
                request = request
            )

            if (response.isSuccessful) {
                val body = response.body()
                val error = body?.error
                if (error != null) {
                    return Result.Error("Gemini error: ${error.message}")
                }
                val text = body?.candidates
                    ?.firstOrNull()
                    ?.content
                    ?.parts
                    ?.firstOrNull()
                    ?.text
                    ?: "I couldn't generate a response. Please try again."
                Result.Success(text)
            } else {
                val errMsg = response.errorBody()?.string() ?: ""
                Result.Error("API error: ${response.code()} $errMsg")
            }
        } catch (e: Exception) {
            Result.Error(e.message ?: "Network error")
        }
    }
}

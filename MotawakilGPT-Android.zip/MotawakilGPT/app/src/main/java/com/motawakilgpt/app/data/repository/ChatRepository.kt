package com.motawakilgpt.app.data.repository

import com.motawakilgpt.app.data.models.*
import com.motawakilgpt.app.network.RetrofitClient
import com.motawakilgpt.app.utils.SessionManager
import com.motawakilgpt.app.utils.bearerToken
import kotlinx.coroutines.flow.first

class ChatRepository(private val sessionManager: SessionManager) {

    private val dbService = RetrofitClient.supabaseDbService

    private suspend fun getToken(): String? = sessionManager.accessToken.first()
    private suspend fun getUserId(): String? = sessionManager.userId.first()

    suspend fun getChats(): Result<List<Chat>> {
        return try {
            val token = getToken() ?: return Result.Error("Not authenticated")
            val response = dbService.getChats(bearerToken(token))
            if (response.isSuccessful) {
                Result.Success(response.body() ?: emptyList())
            } else {
                Result.Error("Failed to load chats")
            }
        } catch (e: Exception) {
            Result.Error(e.message ?: "Network error")
        }
    }

    suspend fun createChat(title: String): Result<Chat> {
        return try {
            val token = getToken() ?: return Result.Error("Not authenticated")
            val userId = getUserId() ?: return Result.Error("Not authenticated")
            val response = dbService.insertChat(
                bearerToken(token),
                InsertChatRequest(userId = userId, title = title)
            )
            if (response.isSuccessful) {
                val chats = response.body()
                val chat = chats?.firstOrNull()
                if (chat != null) Result.Success(chat)
                else Result.Error("Failed to create chat")
            } else {
                Result.Error("Failed to create chat")
            }
        } catch (e: Exception) {
            Result.Error(e.message ?: "Network error")
        }
    }

    suspend fun updateChatTitle(chatId: String, title: String): Result<Unit> {
        return try {
            val token = getToken() ?: return Result.Error("Not authenticated")
            dbService.updateChat(
                bearerToken(token),
                "eq.$chatId",
                mapOf("title" to title)
            )
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e.message ?: "Network error")
        }
    }

    suspend fun updateChatTimestamp(chatId: String): Result<Unit> {
        return try {
            val token = getToken() ?: return Result.Error("Not authenticated")
            val now = java.time.Instant.now().toString()
            dbService.updateChat(
                bearerToken(token),
                "eq.$chatId",
                mapOf("updated_at" to now)
            )
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e.message ?: "Network error")
        }
    }

    suspend fun deleteChat(chatId: String): Result<Unit> {
        return try {
            val token = getToken() ?: return Result.Error("Not authenticated")
            val response = dbService.deleteChat(bearerToken(token), "eq.$chatId")
            if (response.isSuccessful) {
                Result.Success(Unit)
            } else {
                Result.Error("Failed to delete chat")
            }
        } catch (e: Exception) {
            Result.Error(e.message ?: "Network error")
        }
    }

    suspend fun getMessages(chatId: String): Result<List<Message>> {
        return try {
            val token = getToken() ?: return Result.Error("Not authenticated")
            val response = dbService.getMessages(bearerToken(token), "eq.$chatId")
            if (response.isSuccessful) {
                Result.Success(response.body() ?: emptyList())
            } else {
                Result.Error("Failed to load messages")
            }
        } catch (e: Exception) {
            Result.Error(e.message ?: "Network error")
        }
    }

    suspend fun insertMessage(chatId: String, role: String, content: String): Result<Unit> {
        return try {
            val token = getToken() ?: return Result.Error("Not authenticated")
            val userId = getUserId() ?: return Result.Error("Not authenticated")
            val response = dbService.insertMessage(
                bearerToken(token),
                InsertMessageRequest(
                    chatId = chatId,
                    userId = userId,
                    role = role,
                    content = content
                )
            )
            if (response.isSuccessful) {
                Result.Success(Unit)
            } else {
                Result.Error("Failed to save message")
            }
        } catch (e: Exception) {
            Result.Error(e.message ?: "Network error")
        }
    }
}

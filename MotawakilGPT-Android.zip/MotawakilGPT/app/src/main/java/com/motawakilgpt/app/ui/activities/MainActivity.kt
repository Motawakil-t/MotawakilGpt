package com.motawakilgpt.app.ui.activities

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.LocalOnBackPressedDispatcherOwner
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.motawakilgpt.app.data.models.Chat
import com.motawakilgpt.app.ui.*
import com.motawakilgpt.app.ui.viewmodels.AuthViewModel
import com.motawakilgpt.app.ui.viewmodels.ChatViewModel
import com.motawakilgpt.app.utils.I18n
import com.motawakilgpt.app.utils.formatRelativeDate
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val chatViewModel: ChatViewModel by viewModels()
    private val authViewModel: AuthViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MotawakilGPTTheme {
                val chatUiState by chatViewModel.chatUiState.collectAsStateWithLifecycle()
                val authUiState by authViewModel.uiState.collectAsStateWithLifecycle()

                // If logged out, go to landing
                LaunchedEffect(authUiState.isLoggedIn) {
                    if (!authUiState.isLoggedIn && !authUiState.isLoading) {
                        startActivity(
                            Intent(this@MainActivity, LandingActivity::class.java).apply {
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                            }
                        )
                        finish()
                    }
                }

                MainScreen(
                    chatViewModel = chatViewModel,
                    onLogout = { authViewModel.signOut() },
                    onOpenSettings = {
                        startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    chatViewModel: ChatViewModel,
    onLogout: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val chatListState by chatViewModel.chatListState.collectAsStateWithLifecycle()
    val chatUiState by chatViewModel.chatUiState.collectAsStateWithLifecycle()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var showDeleteDialog by remember { mutableStateOf<String?>(null) }

    // Back button: close drawer if open, else back navigation
    val context = LocalContext.current
    val backDispatcher = LocalOnBackPressedDispatcherOwner.current?.onBackPressedDispatcher
    DisposableEffect(drawerState.isOpen) {
        val callback = object : OnBackPressedCallback(drawerState.isOpen) {
            override fun handleOnBackPressed() {
                scope.launch { drawerState.close() }
            }
        }
        backDispatcher?.addCallback(callback)
        onDispose { callback.remove() }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = true,
        drawerContent = {
            ModalDrawerSheet(
                modifier = Modifier.width(300.dp),
                drawerContainerColor = Color(0xFFF8F9FF)
            ) {
                ChatSidebar(
                    chats = chatListState.chats,
                    activeChatId = chatUiState.currentChatId,
                    userEmail = chatUiState.userEmail,
                    onNewChat = {
                        chatViewModel.newChat()
                        scope.launch { drawerState.close() }
                    },
                    onChatSelected = { chatId ->
                        chatViewModel.openChat(chatId)
                        scope.launch { drawerState.close() }
                    },
                    onDeleteChat = { chatId ->
                        showDeleteDialog = chatId
                    },
                    onLogout = onLogout,
                    onOpenSettings = onOpenSettings
                )
            }
        }
    ) {
        Column(modifier = Modifier.fillMaxSize().background(Color.White)) {
            // Top bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { scope.launch { drawerState.open() } }) {
                    Icon(
                        imageVector = Icons.Default.Menu,
                        contentDescription = "Menu",
                        tint = MotawakilColors.Foreground
                    )
                }
                BrandMark(size = 28.dp)
                IconButton(onClick = { chatViewModel.newChat() }) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "New Chat",
                        tint = MotawakilColors.Foreground
                    )
                }
            }
            Divider(color = MotawakilColors.Border)

            // Chat window
            ChatWindow(
                chatViewModel = chatViewModel
            )
        }
    }

    // Delete dialog
    if (showDeleteDialog != null) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = null },
            title = { Text(I18n.t("delete_chat")) },
            text = { Text(I18n.t("confirm_delete")) },
            confirmButton = {
                TextButton(
                    onClick = {
                        chatViewModel.deleteChat(showDeleteDialog!!)
                        showDeleteDialog = null
                    }
                ) {
                    Text(I18n.t("delete"), color = MotawakilColors.Destructive)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = null }) {
                    Text(I18n.t("cancel"))
                }
            }
        )
    }
}

@Composable
fun ChatSidebar(
    chats: List<Chat>,
    activeChatId: String?,
    userEmail: String,
    onNewChat: () -> Unit,
    onChatSelected: (String) -> Unit,
    onDeleteChat: (String) -> Unit,
    onLogout: () -> Unit,
    onOpenSettings: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 8.dp)
    ) {
        // Logo
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BrandMark(size = 28.dp)
        }

        Spacer(modifier = Modifier.height(8.dp))

        // New Chat button
        GradientButton(
            text = I18n.t("new_chat"),
            onClick = onNewChat,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Recent label
        Text(
            text = I18n.t("recent"),
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = MotawakilColors.MutedForeground,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
        )

        // Chat list
        LazyColumn(modifier = Modifier.weight(1f)) {
            if (chats.isEmpty()) {
                item {
                    Text(
                        text = I18n.t("no_chats"),
                        fontSize = 13.sp,
                        color = MotawakilColors.MutedForeground,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                    )
                }
            } else {
                items(chats) { chat ->
                    ChatListItem(
                        chat = chat,
                        isActive = chat.id == activeChatId,
                        onClick = { onChatSelected(chat.id) },
                        onDelete = { onDeleteChat(chat.id) }
                    )
                }
            }
        }

        Divider(color = MotawakilColors.Border)

        // User info + settings + logout
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(BrandGradient),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = userEmail.firstOrNull()?.uppercaseChar()?.toString() ?: "U",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = userEmail,
                    fontSize = 12.sp,
                    color = MotawakilColors.MutedForeground,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(
                    onClick = onOpenSettings,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(I18n.t("settings"), fontSize = 13.sp)
                }
                TextButton(
                    onClick = onLogout,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.ExitToApp,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(I18n.t("logout"), fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun ChatListItem(
    chat: Chat,
    isActive: Boolean,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    var showDelete by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(
                if (isActive) Color(0xFFEBEEFF) else Color.Transparent
            )
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = chat.title.ifBlank { I18n.t("new_chat") },
                fontSize = 13.sp,
                fontWeight = if (isActive) FontWeight.SemiBold else FontWeight.Normal,
                color = if (isActive) MotawakilColors.Foreground else MotawakilColors.MutedForeground,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = chat.updatedAt.formatRelativeDate(),
                fontSize = 11.sp,
                color = MotawakilColors.MutedForeground
            )
        }
        IconButton(
            onClick = onDelete,
            modifier = Modifier.size(32.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Delete,
                contentDescription = "Delete",
                tint = MotawakilColors.MutedForeground,
                modifier = Modifier.size(15.dp)
            )
        }
    }
}

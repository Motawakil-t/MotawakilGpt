package com.motawakilgpt.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Brand colors matching the website CSS
object MotawakilColors {
    val BrandNavy = Color(0xFF1E2E6E)
    val BrandCyan = Color(0xFF3BACD4)
    val BrandAzure = Color(0xFF2C6BC4)
    val BrandPurple = Color(0xFF6B3FC4)
    val BrandGold = Color(0xFFC4A830)

    val Background = Color(0xFFFFFFFF)
    val Foreground = Color(0xFF1E2E6E)
    val Surface = Color(0xFFF8F9FF)
    val SurfaceVariant = Color(0xFFF0F2FF)
    val Primary = Color(0xFF1E2E6E)
    val PrimaryForeground = Color(0xFFF8F9FF)
    val Secondary = Color(0xFFF0F2FF)
    val SecondaryForeground = Color(0xFF1E2E6E)
    val Muted = Color(0xFFF0F2FF)
    val MutedForeground = Color(0xFF5A6A9A)
    val Border = Color(0x1F1E2E6E)
    val Destructive = Color(0xFFE53935)

    val GradientStart = Color(0xFF1E2E6E)
    val GradientMid = Color(0xFF2C5CC4)
    val GradientEnd = Color(0xFF3BACD4)
}

private val LightColorScheme = lightColorScheme(
    primary = MotawakilColors.Primary,
    onPrimary = MotawakilColors.PrimaryForeground,
    primaryContainer = MotawakilColors.SurfaceVariant,
    onPrimaryContainer = MotawakilColors.Foreground,
    secondary = MotawakilColors.Secondary,
    onSecondary = MotawakilColors.SecondaryForeground,
    secondaryContainer = MotawakilColors.SurfaceVariant,
    onSecondaryContainer = MotawakilColors.Foreground,
    tertiary = MotawakilColors.BrandCyan,
    onTertiary = Color.White,
    background = MotawakilColors.Background,
    onBackground = MotawakilColors.Foreground,
    surface = MotawakilColors.Surface,
    onSurface = MotawakilColors.Foreground,
    surfaceVariant = MotawakilColors.SurfaceVariant,
    onSurfaceVariant = MotawakilColors.MutedForeground,
    outline = MotawakilColors.Border,
    error = MotawakilColors.Destructive,
    onError = Color.White,
)

@Composable
fun MotawakilGPTTheme(
    darkTheme: Boolean = false, // Always light per website design
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        content = content
    )
}
